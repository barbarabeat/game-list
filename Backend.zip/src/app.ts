import * as express from 'express';
import * as cors from 'cors';

import routes from './routes';
import  database from './database';

class App {
  public express: express.Application

  public constructor () {
    this.express = express();

    this.middlewares();
    this.database();
    this.routes();
  }

  private middlewares(): void {
    this.express.use(express.json());
    this.express.use(cors());
  }

  private database(): any {
    this.express.connect(database);
  }

  private routes(): void {
    this.express.use(routes);
  }
}

export default new App().express;
