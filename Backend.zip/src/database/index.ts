import { Connection, createConnection } from 'typeorm';

const database:Promise<Connection> = createConnection();

export default database;
