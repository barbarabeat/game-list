import { Router } from 'express';

const routes = Router();

export default routes;
