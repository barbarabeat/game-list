import {NextFunction, Request, Response} from 'express';

import App from './app';

import AppError from './errors/AppError';

App.use((err: Error, req: Request, resp: Response, next: NextFunction)=>{
  if(err instanceof AppError){
    return resp.status(err.statusCode).json({
      status: 'error',
      message: err.message
    });
  }
  console.log(err);

  return resp.status(500).json({
    status: 'error',
    message: 'Internal sever error'
  });
},
);

App.listen(3333, () => {
  // eslint-disable-next-line no-console
  console.log(':rocket: Server started on port 3333');
});
